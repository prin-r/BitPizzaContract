import React from 'react';
import ReactDOM from 'react-dom';
// import BitPizzaApp from './components/BitPizzaApp';
import AppRouter from './routers/AppRouter';

ReactDOM.render(<AppRouter />, document.getElementById('app'));
