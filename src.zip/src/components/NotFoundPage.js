import React from 'react';

const NotFoundPage = () => {
  return (
    <h1>404 Not Found Page</h1>
  );
}

export default NotFoundPage;
